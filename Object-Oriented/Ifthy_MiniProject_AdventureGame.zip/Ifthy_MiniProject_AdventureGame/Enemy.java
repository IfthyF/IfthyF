// Enemy inherits Character
public class Enemy extends Character
{ 
    private int points;
    private boolean deadStatus;
    // Constructor of Enemy with extra info assigned to enemy.
    public Enemy(String name, int health, int points, int defense){
        super(name, health, defense);
        this.points = points;
        this.deadStatus = false;
    }
    
    // method gets points worth of particular enemy
    public int getPoints(){
        return points;
    }
    
    // killed method sets instance variable deadStatus true as enemy is dead.
    public void killed(){
        deadStatus = true;
    }
    
    // gets the death status of enemy (true = dead and false = alive)
    public boolean getDeadStatus(){
        return deadStatus;
    }

    
    //getStats method shows enemy stats
    public String getStats(){
        String res = "Enemy character "+getName()+ " has "+getHealth()+" health.\n"+getName();
        return res;
    }
    
    // method gives a random chance of hitting the enemy (normal 30 damage or critical 60 damage) or missing (losing health) to the player character.
    // Also if defense of player character is higher than enemy then there is a 10% less chance of getting hit and vice versa.
    // This returns the damage done.
    public int damageNPC(Character PC){
        PlayerCharacter PC_obj = (PlayerCharacter) PC;
        double chance = Math.random();
        if (PC.getDefence() > this.getDefence()){
            System.out.println("You have greater defense which gives a 10% less chance of getting hit");
            chance = chance + 0.10;
        }
        if (PC.getDefence() < this.getDefence()){
            System.out.println("You have lesser defense which gives a 10% more chance of getting hit");
            chance = chance - 0.10;
        }
        int damage = 0;
        if (chance < 0.35){
            System.out.println("You missed a hit and taken damage");
            return damage;
        }
        else if (chance < 0.85) {
            System.out.println("You hit the enemy (normal damage given)");
            damage = PC_obj.getWeaponDamage();
            return damage;
        }
        else {
            System.out.println("You gave a critical hit to the enemy (normal + 20 damage given)");
            damage = PC_obj.getWeaponDamage() + 20;
            return damage;
        }
    }
    
    // method returns damage done to player character.
    public int damagePC(){
        int damage = 10;
        return damage;
    }
    
    // getStatus() method shows enemy status.
    @Override //overriding the getStatus() method
    public String getStatus(){
        String res = "Enemy "+super.getStatus();
        return res;
    }
    
}
