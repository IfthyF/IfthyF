import java.util.Random;

// Goblin inherits Enemy
public class Goblin extends Enemy
{
    private String weaponType;
    
    // Constructor of Goblin assigns properties of superclass and weapon of enemy goblin. Health of goblin is 60 and points worth is 4.
    public Goblin(String name){
        super(name, 60, 4, ((int)(Math.random() * ((2 - 1) + 1)) + 1));
        String []list = {"Club","Small Knife","Nothing"};
        Random random = new Random();
        int choice = random.nextInt(list.length);
        this.weaponType = list[choice];
    }
    
    // method gets weapon type of goblin
    public String getWeaponType(){
        return weaponType;
    }
    
    // getStats() shows what goblin stats and damage they can do to player character.
    @Override //overriding getStats() method
    public String getStats(){
        String res = super.getStats()+" has a "+getWeaponType()+" and is worth "+getPoints()+" points and has "+getDefence()+ " defense.";
        res = res+"\nGoblins deal 20 damage to player character if player character misses.";
        return res;
    }
    
    // getStatus() method in subclass Goblin shows enemy goblin status if they are dead or not.
    @Override //overring getStatus() method
    public String getStatus(){
        String res = super.getStatus();
        if (getDeadStatus()){
            res = res+" and is dead and you have gained "+getPoints()+" points from killing the Goblin.";
        }
        else {
            res = res+" and is not dead. \nYou can either choose the other options or fight the Goblin again (Watch out for 20 damage to you if you miss)";
        }
        return res;
    }
    
    // damageNPC() method returns damage done to goblin.
    // Damage to goblin can be increased by 20 by a 30% chance.
    @Override //overriding the damageNPC() method
    public int damageNPC(Character PC){
        int damage = super.damageNPC(PC);
        if (damage == 0){
            return damage;
        }
        else{
            if (Math.random() < 0.3){
                System.out.println("Damage to Goblin is increased by 20");
                damage = damage + 20;
            }
            return damage;
        }
    }
    
    //damagePC() method returns damage done to player character based on weapon of goblin.
    @Override //overriding the damagePC() method
    public int damagePC(){
        if (weaponType.equals("Club")){
            return 20;
        }
        else if (weaponType.equals("Small Knife")){
            return 10;
        }
        else {
            return super.damagePC() - 5;
        }
    }
}
