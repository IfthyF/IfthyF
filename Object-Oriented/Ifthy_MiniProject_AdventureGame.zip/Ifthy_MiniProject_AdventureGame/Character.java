/* This is the superclass Character.
   This contains the main properties of each character in the game.
   Which includes name, health and defense. */
public class Character
{
    private String name;
    private int health;
    private int defence;
    private int weaponDamage;
    
    // Constructor which assigns the name, health and defense points (either 1 or 2) of characters except Trader's defense which is 0.
    public Character(String name, int health, int defence){
        this.name = name;
        this.health = health;
        this.defence = defence;
    }
    
    // method increases health of character
    public void increaseHealth(int value){
        health = health + value;
    }
    
    // method decreases health of character
    public void decreaseHealth(int value){
        health = health - value;
    }
    
    // method sets health
    public void setHealth(int newHealth){
        health = newHealth;
    }
    
    // method gets name of character
    public String getName(){
        return name;
    }
    
    // method gets health of character
    public int getHealth(){
        return health;
    }
    
    // method gets defense stat of character
    public int getDefence(){
        return defence;
    }
    
    // getStatus method is overridden in subclasses of superclass Character
    // This method shows the status of the character.
    public String getStatus(){
        String res = "character's name is "+name+" and their health is "+health;
        return res;
    }
    
}
