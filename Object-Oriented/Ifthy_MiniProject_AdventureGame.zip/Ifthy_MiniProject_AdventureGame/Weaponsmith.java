// Weaponsmith inherits Friend
public class Weaponsmith extends Friend
{
    private int damageIncrease;
    
    // Constructor of Weaponsmith assigns properties of weaponsmith character
    public Weaponsmith(String name){
        super(name);
        damageIncrease = 0;
    }
    
    // method returns points that are required for that item choice (Spear or Axe) by player character
    @Override // overriding the getPrice() method 
    public int getPrice(){
        if (getItemWanted().equals("Spear")){
            setPrice(8);
        }
        else if (getItemWanted().equals("Axe")){
            setPrice(9);
        }
        return super.getPrice();
    }
    
    // method gets damage boost from player weapon choice
    public int getDamageIncrease(){
        if (getItemWanted().equals("Spear")){
            damageIncrease = 10;
        }
        else if (getItemWanted().equals("Axe")){
            damageIncrease = 15;
        }
        return damageIncrease;
    }
    
    // getStatus() method in shows status of weaponsmith and transaction done with weaponsmith.
    @Override //overriding the getStatus() method
    public String getStatus(){
        String res = super.getStatus();
        res = res + "\nYou have taken "+getItemWanted()+" which has costed "+getPrice()
        +" which provides "+damageIncrease+" more damage than a sword to enemies.";
        return res;
    }
}
