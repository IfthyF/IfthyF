import java.util.*;
public class TestMainGame
{
    // inputString method allows user to input string value and return that value as a response from a question or message.
    public static String inputString(String message)
    {
        Scanner scanner = new Scanner(System.in);
        String answer;
        System.out.println(message);
        answer = scanner.nextLine();
        return answer;
    }
    
    // creates PlayerCharacter object with name which the user inputs.
    public static PlayerCharacter createPC(){
        String name = inputString("What is your character's name: ");
        PlayerCharacter player = new PlayerCharacter(name);
        return player;
    }
    
    // Checks the main options user can do returns true if they are valid options for game.
    public static boolean check1(String choice){
        String f = "f";
        String g = "g";
        String t = "t";
        String e = "e";
        String b = "b";
        String w = "w";
        if (choice.equals(f)){return true;}
        else if (choice.equals(g)){return true;}
        else if (choice.equals(t)){return true;}
        else if (choice.equals(e)){return true;}
        else if (choice.equals(b)){return true;}
        else if (choice.equals(w)){return true;}
        else{return false;}
    }
    
    // Checks the options user can do returns true if they are valid options for trader transaction.
    public static boolean check2(String choice){
        String a = "Apple";
        String c = "Carrot";
        String e = "Exit";
        if (choice.equals(a)){return true;}
        else if (choice.equals(c)){return true;}
        else if (choice.equals(e)){return true;}
        else{return false;}
    }
    
    // Checks the options user can do returns true if they are valid options for weaponsmith transaction.
    public static boolean check3(String choice){
        String s = "Spear";
        String a = "Axe";
        String e = "Exit";
        if (choice.equals(s)){return true;}
        else if (choice.equals(a)){return true;}
        else if (choice.equals(e)){return true;}
        else{return false;}
    }
    
    // Main method
    public static void main(String[] args){
        Enemy[] level = new Enemy[3];
        level[0] = new Troll("Billy (Type: Troll)"); // substitution princple
        level[1] = new Goblin("Stewart (Type: Goblin)"); // substitution princple
        level[2] = new Beast("Logan (Type: Beast)"); // substitution princple
        Trader trader = new Trader("Joe (Type: Trader)");
        Weaponsmith weaponsmith = new Weaponsmith("Sam (Type: Weaponsmith)");
        
        System.out.println("Adventure Game");
        System.out.println();
        System.out.println();
        Character PC = createPC(); 
        System.out.println();
        System.out.println();
        System.out.println("Welcome "+PC.getName());
        System.out.println("Your aim is to kill all enemies in this forest");
        System.out.println();
        System.out.println();
        int remain = 0;
        for (int i=0; i<level.length; i++){
            if (level[i] instanceof Troll | level[i] instanceof Goblin | level[i] instanceof Beast){
                remain = remain + 1;
            }
        }
        if (remain == 1){
            System.out.println("There is "+remain+" enemy in this forest");
        }
        else{
            System.out.println("There are "+remain+" enemies in this forest");
        }
        System.out.println();
        System.out.println("You have a random fighting choice of either getting a normal hit (30 damage with sword)"+
        " or critical hit (normal + 20 damage with sword) or miss and losing health.");
        System.out.println("If you do hit either a critical or normal hit then you get:");
        System.out.println("30% chance that you deliver 20 more damage than normal to Goblins");
        System.out.println("20% chance that you deliver 10 more damage than normal to Trolls");
        System.out.println("15% chance that you deliver 10 more damage than normal to Beasts");
        System.out.println("Goblins have 60 HP, Trolls have 80 HP and Beasts have 100 HP");
        System.out.println();
        System.out.println("The player character and enemies each have a defense point either 1 or 2.");
        System.out.println("If the player character has a higher defense than the enemy then they would have a 10% less chance of getting hit and losing health.");
        System.out.println("Otherwise the player character would have a 10% more chance of getting hit and losing health.");
        System.out.println();
        while(PC.getHealth() > 0 & remain > 0){
            System.out.println(PC.getStatus());
            System.out.println();
            options(level, remain);
            String ans = inputString("Please enter an option");
            while (!check1(ans)){
                System.out.println("Please choose a valid option");
                ans = inputString("Please enter an option");
            }
            System.out.println();
            System.out.println();
            PlayerCharacter PC_cast = (PlayerCharacter) PC;
            if (ans.equals("f")){
                System.out.println();
                System.out.println();
                for (int i=0; i<level.length; i++){
                    if (level[i] instanceof Troll && level[i].getHealth() > 0){
                        System.out.println();
                        System.out.println(level[i].getStats());
                        System.out.println();
                        int damage = level[i].damageNPC(PC); // polymorphic statement
                        if (damage == 0){
                            PC.decreaseHealth(level[i].damagePC()); // polymorphic statement
                        }
                        else {
                            level[i].decreaseHealth(damage);
                        }
                        if (level[i].getHealth() <= 0){ 
                            PC_cast.increasePointsBalance(level[i].getPoints()); 
                            level[i].killed(); 
                        }
                        System.out.println();
                        System.out.println(level[i].getStatus()); 
                        if (level[i].getDeadStatus()){ 
                            remain = remain - 1; 
                            level[i] = null; 
                        }
                        System.out.println();
                        System.out.println();
                        System.out.println("There are still "+remain+" enemies remaining in this forest"); 
                    }
                }
            }
            else if (ans.equals("g")){
                System.out.println();
                System.out.println();
                for (int i=0; i<level.length; i++){
                    if (level[i] instanceof Goblin && level[i].getHealth() > 0){ 
                        System.out.println();
                        System.out.println(level[i].getStats()); 
                        System.out.println();
                        int damage = level[i].damageNPC(PC); //polymorphic statement
                        if (damage == 0){
                            PC.decreaseHealth(level[i].damagePC()); // polymorphic statement
                        }
                        else {
                            level[i].decreaseHealth(damage); 
                        }
                        if (level[i].getHealth() <= 0){ 
                            PC_cast.increasePointsBalance(level[i].getPoints()); 
                            level[i].killed(); 
                        }
                        System.out.println();
                        System.out.println(level[i].getStatus()); 
                        if (level[i].getDeadStatus()){ 
                            remain = remain - 1; 
                            level[i] = null; 
                        }
                        System.out.println();
                        System.out.println();
                        System.out.println("There are still "+remain+" enemies remaining in this forest");
                    }
                }
            }
            else if (ans.equals("b")){
                System.out.println();
                System.out.println();
                for (int i=0; i<level.length; i++){
                    if (level[i] instanceof Beast && level[i].getHealth() > 0){
                        System.out.println();
                        System.out.println(level[i].getStats()); 
                        System.out.println();
                        int damage = level[i].damageNPC(PC); //polymorphic statement
                        if (damage == 0){
                            PC.decreaseHealth(level[i].damagePC()); // polymorphic statement
                        }
                        else {
                            level[i].decreaseHealth(damage);
                        }
                        if (level[i].getHealth() <= 0){ 
                            PC_cast.increasePointsBalance(level[i].getPoints()); 
                            level[i].killed(); 
                        }
                        System.out.println();
                        System.out.println(level[i].getStatus());
                        if (level[i].getDeadStatus()){
                            remain = remain - 1;
                            level[i] = null;
                        }
                        System.out.println();
                        System.out.println();
                        System.out.println("There are still "+remain+" enemies remaining in this forest");
                    }
                }
            }
            else if (ans.equals("t")){
                System.out.println();
                System.out.println();
                System.out.println(PC.getStatus());
                System.out.println();
                System.out.println("What food item you want to buy");
                System.out.println("You can get either Apple (6 points) or Carrot (3 points) or Exit");
                String choice2 = inputString("Enter Choice: ");
                System.out.println();
                while (!check2(choice2)){ 
                    System.out.println("Please choose a valid option");
                    choice2 = inputString("Enter Choice: ");
                }
                if (choice2.equals("Exit")){ 
                    System.out.println();
                    System.out.println("You have finished trading");
                }
                else{
                    System.out.println();
                    trader.setItemWanted(choice2); 
                    int points_needed = trader.getPrice(); 
                    while(PC_cast.getPointsBalance() < points_needed){ 
                        System.out.println("Sorry you do not have enough points for this item");
                        System.out.println("Please enter another choice");
                        choice2 = inputString("Enter Choice: ");
                        trader.setItemWanted(choice2);
                        points_needed = trader.getPrice();
                    }
                    PC_cast.decreasePointsBalance(points_needed); 
                    PC.increaseHealth(trader.getHealthPoints()); 
                    if (PC.getHealth() > 100){ 
                        PC.setHealth(100);
                    }
                    System.out.println();
                    System.out.println(trader.getStatus()); 
                    System.out.println();
                    System.out.println("You have finished trading returning to forest");
                }
            }
            else if (ans.equals("w")){
                System.out.println();
                System.out.println();
                System.out.println(PC.getStatus());
                System.out.println();
                System.out.println("What weapon do you want to buy");
                System.out.println("You can get either a Spear (8 points) or Axe (9 points) or Exit");
                String choice3 = inputString("Enter Choice:");
                System.out.println();
                while (!check3(choice3)){ 
                    System.out.println("Please choose a valid option");
                    choice3 = inputString("Enter Choice: ");
                }
                if (choice3.equals("Exit")){ 
                    System.out.println();
                    System.out.println("You have finished trading returning to level");
                }
                else{
                    System.out.println();
                    weaponsmith.setItemWanted(choice3);
                    int points_needed = weaponsmith.getPrice();
                    while(PC_cast.getPointsBalance() < points_needed){ 
                        System.out.println("Sorry you do not have enough points for this item");
                        System.out.println("Please enter another choice");
                        choice3 = inputString("Enter Choice: ");
                        weaponsmith.setItemWanted(choice3);
                        points_needed = weaponsmith.getPrice();
                    }
                    PC_cast.setWeaponType(choice3);
                    PC_cast.setWeaponDamage(30+weaponsmith.getDamageIncrease());
                    PC_cast.decreasePointsBalance(points_needed);
                    System.out.println();
                    System.out.println();
                    System.out.println(weaponsmith.getStatus());
                    System.out.println();
                    System.out.println("You have finished trading returning to forest");
                }
            }
            else if (ans.equals("e")){
                System.out.println();
                System.out.println("You have exited the game.");
                System.out.println("You have exited the game.");
                System.out.println("Thank you for playing");
                System.exit(0);
            }
            else {
                System.out.println();
                System.out.println("You have exited the game.");
                System.out.println("You have exited the game.");
                System.out.println("Thank you for playing");
                System.exit(0);
            }
        }
        System.out.println();
        System.out.println();
        System.out.println("The Game has now ended.");
        if (remain >= 1){
            System.out.println("You have died and have not been able to kill all enemies.");
        }
        else{
            System.out.println("You won by killing all enemies.");
        }
    }
    
    //Shows the main options for the game.
    public static void options(Character[] level, int remain){
        for (int i=0; i<level.length; i++){
            if (remain > 0 && level[i] instanceof Troll){ 
                System.out.println("You can enter f to start a fight with "+level[i].getName());
            }
            if (remain > 0 && level[i] instanceof Goblin){ 
                System.out.println("You can enter g to start a fight with "+level[i].getName());
            }
            if (remain > 0 && level[i] instanceof Beast){ 
                System.out.println("You can enter b to start a fight with "+level[i].getName());
            }
        }
        System.out.println("You can enter t to leave forest to trade points for food with trader");
        System.out.println("You can enter w to leave forest to trade points for weapons with weapon smith");
        System.out.println("You can enter e to end game");
    }
}
