import java.util.Random;

// Troll inherits Enemy
public class Troll extends Enemy
{
    private String weaponType;
    
    // Constructor of Troll assigns properties of superclass and weapon of enemy troll.
    public Troll(String name){
        super(name, 80, 5, ((int)(Math.random() * ((2 - 1) + 1)) + 1));
        String []list = {"Mace","Hammer","Nothing"};
        Random random = new Random();
        int choice = random.nextInt(list.length);
        this.weaponType = list[choice];
    }
    
    // method gets weapon type of troll
    public String getWeaponType(){
        return weaponType;
    }
    
    // getStats() shows what troll stats and damage they can do to player character
    @Override
    public String getStats(){
        String res = super.getStats()+" has a "+getWeaponType()+" and is worth "+getPoints()+" points and has "+getDefence()+ " defense.";
        res = res+"\nTrolls deal 30 damage to player character if player character misses.";
        return res;
    }
    
    // getStatus() method in subclass Troll shows enemy troll status if they are dead or not.
    @Override //overriding the getStatus() method
    public String getStatus(){
        String res = super.getStatus();
        if (getDeadStatus()){
            res = res+" and is dead and you have gained "+getPoints()+" points from killing the Troll.";
        }
        else {
            res = res+" and is not dead. \nYou can either choose the other options or fight the Troll again (Watch out for 30 damage to you if you miss).";
        }
        return res;
    }
    
    // damageNPC() method returns damage done to troll.
    // Damage to troll can be increased by 10 by a 20% chance.
    @Override //overriding the damageNPC() method
    public int damageNPC(Character PC){
        int damage = super.damageNPC(PC);
        if (damage == 0){
            return damage;
        }
        else{
            if (Math.random() < 0.2){
                System.out.println("Damage to Troll is increased by 10");
                damage = damage + 10;
            }
            return damage;
        }
    }
    
    // damagePC() method returns damage done to player character based on weapon of troll.
    @Override //overriding the damagePC() method
    public int damagePC(){
        if (weaponType.equals("Mace")){
            return 20;
        }
        else if (weaponType.equals("Axe")){
            return 30;
        }
        else {
            return super.damagePC();
        }
    }
}
