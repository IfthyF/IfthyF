// Trader inherits Friend
public class Trader extends Friend
{
    private int healthValue;
    
    //Constructor of Trader assigns properties of trader character
    public Trader(String name){
        super(name);
        healthValue = 0;
    }
    
    // getPrice() method returns points that are required to buy food (Apple or Carrot).
    @Override // overriding the getPrice() method
    public int getPrice(){
        if (getItemWanted().equals("Apple")){
            setPrice(6);
        }
        else if (getItemWanted().equals("Carrot")){
            setPrice(3);
        }
        return super.getPrice();
    }
    
    // getHealthPoints() method returns the health increase value the player gets from eating the food.
    public int getHealthPoints(){
        if (getItemWanted().equals("Apple")){
            healthValue = 30;
        }
        else if (getItemWanted().equals("Carrot")){
            healthValue = 10;
        }
        return healthValue;
    }
    
    // getStatus() method in shows status of trader and transaction done with trader.
    @Override //overriding the getStatus() method
    public String getStatus(){
        String res = super.getStatus();
        res = res + "\nYou have taken "+getItemWanted()+" which has costed "+getPrice()+
        "\n and has given you "+healthValue+" to your health.";
        return res;
    }
}
