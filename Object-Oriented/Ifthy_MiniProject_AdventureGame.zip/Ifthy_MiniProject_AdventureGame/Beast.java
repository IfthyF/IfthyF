import java.util.Random;

// Beast inherits Enemy
public class Beast extends Enemy
{
    private String weaponType;
    
    // Constructor of Beast assigns properties of superclass and weapon of enemy beast.
    public Beast(String name){
        super(name, 100, 6, ((int)(Math.random() * ((2 - 1) + 1)) + 1));
        String []list = {"Claws","Nothing"};
        Random random = new Random();
        int choice = random.nextInt(list.length);
        this.weaponType = list[choice];
    }

    //method gets weapon type of beast
    public String getWeaponType(){
        return weaponType;
    }
    
    // getStats() shows what beast stats and damage they can do to player character.
    @Override //overriding getStats() method
    public String getStats(){
        String res = super.getStats()+" has "+getWeaponType()+" and is worth "+getPoints()+" points and has "+getDefence()+ " defense.";
        res = res+"\nBeasts deal 40 damage to player character if player character misses.";
        return res;
    }
    
    // getStatus() method in subclass Beast shows enemy beast status if they are dead or not.
    @Override //overriding getStatus() method
    public String getStatus(){
        String res = super.getStatus();
        if (getDeadStatus()){
            res = res+" and is dead and you have gained "+getPoints()+" points from killing the Beast.";
        }
        else {
            res = res+" and is not dead. \nYou can either choose the other options or fight the Beast again (Watch out for 40 damage to you if you miss)";
        }
        return res;
    }
    
    // damageNPC() method returns damage done to beast.
    // Damage to beast can be increased by 10 by a 15% chance.
    @Override //overriding the damageNPC() method
    public int damageNPC(Character PC){
        int damage = super.damageNPC(PC);
        if (damage == 0){
            return damage;
        }
        else{
            if (Math.random() < 0.15){
                System.out.println("Damage to Beast is increased by 10");
                damage = damage + 10;
            }
            return damage;
        }
    }
    
    //damagePC method returns damage done to player character based on weapon of beast.
    @Override //overriding the damagePC() method
    public int damagePC(){
        if (weaponType.equals("Claws")){
            return 40;
        }
        else {
            return super.damagePC() + 20;
        }
    }
}
