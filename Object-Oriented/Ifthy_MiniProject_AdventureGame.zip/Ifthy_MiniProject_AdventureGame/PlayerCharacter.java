// PlayerCharcter inherits Character
public class PlayerCharacter extends Character
{  
    private String weaponType;
    private int pointsBalance;
    private int weaponDamage;
    
    // Constructor of subclass PlayerCharacter with extra info assigned which are weapon type and points.
    public PlayerCharacter(String name){
        super(name, 100, ((int) (Math.random()*(3 - 1))) + 1);
        this.weaponType = "Sword";
        this.pointsBalance = 0;
        this.weaponDamage = 30;
    }
    
    // method sets weapon type for player character
    public void setWeaponType(String weapon){
        weaponType = weapon;
    }
    
    // method sets damage of current weapon for player character
    public void setWeaponDamage(int damage){
        weaponDamage = damage;
    }
    
    // method gets weapon type of player character
    public String getWeaponType(){
        return weaponType;
    }
    
    // method gets damage of current weapon of player character
    public int getWeaponDamage(){
        return weaponDamage;
    }
    
    // method increases points balance of player character
    public void increasePointsBalance(int points){
        pointsBalance = pointsBalance + points;
    }
    
    // method decreases points balance of player character
    public void decreasePointsBalance(int points){
        pointsBalance = pointsBalance - points;
    }
    
    // method gets poinst balance of player character
    public int getPointsBalance(){
        return pointsBalance;
    }
    
    // getStatus method in subclass PlayerCharacter shows extra status info of player character.
    @Override // overidding getStatus() method.
    public String getStatus(){
        String res = "Player "+super.getStatus();
        res = res + "\n"+getName()+" has a "+getWeaponType()+" which deals "+getWeaponDamage()+" damage.\n"+getName()+
        " has "+getPointsBalance()+" points in their balance and has "+getDefence()+ " defense.";
        return res;
    }
    
}
