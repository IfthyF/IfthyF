// Friend inherits Chraracter
public class Friend extends Character
{
    private int price;
    private String item_wanted;
    
    // Constructor assigns the properties of friend
    public Friend(String name){
        super(name, 100, 0);
        this.price = 0;
    }
    
    // sets price of item wanted by player character
    public void setPrice(int points){
        price = points;
    }
    
    // gets price of item wanted by player character
    public int getPrice(){
        return price;
    }
    
    // sets item wanted by player character
    public void setItemWanted(String item){
        item_wanted = item;
    }
    
    // gets item wanted by player character
    public String getItemWanted(){
        return item_wanted;
    }
    
    // shows name and health of friend character
    public String getStatus(){
        String res = "Friend character name is "+getName();
        return res;
    }
}
